﻿using AutoMapper;
using CRMSolution.Data.Models;
using CRMSolution.Data.Repository;
using CRMSolution.Data.Repository.Interface;
using CRMSolution.DTO.Requests.Task;
using CRMSolution.Services.Interfaces;
using TaskStatus = CRMSolution.Data.Models.TaskStatus;

namespace CRMSolution.Services.Classes;

public class TasksService : ITasksService
{
    private readonly IUnitOfWork _unitOfWork;
    private readonly IMapper _mapper;
    private readonly ILogger<TasksService> _logger;

    public TasksService(IUnitOfWork unitOfWork, IMapper mapper, ILogger<TasksService> logger)
    {
        _unitOfWork = unitOfWork;
        _mapper = mapper;
        _logger = logger;
    }
    
    public async Task CreateTaskAsync(CreateTaskRequest request)
    {
        _logger.LogInformation("Создаем новую задачу: {@Request}", request);
        
        Order order = await _unitOfWork.OrderRep.GetById(Guid.Parse(request.orderId));
        
        User user = await _unitOfWork.UserRep.GetById(Guid.Parse(request.userId));
        
        Tasks task = _mapper.Map<Tasks>(request);
        await _unitOfWork.TasksRep.AddDependency(order, user, task);
        await _unitOfWork.SaveChangesAsync();
    }

    public async Task UpdateTaskAsync(UpdateTaskRequest request)
    {
        _logger.LogInformation("Обновляем задачу: {@Request}", request);
        Tasks task = await _unitOfWork.TasksRep.GetById(Guid.Parse(request.taskId));
        task = _mapper.Map<Tasks>(request);
        await _unitOfWork.SaveChangesAsync();
    }

    public async Task DeleteTaskAsync(DeleteTaskRequest request)
    {
        _logger.LogInformation("Удаляем задачу: {@Request}", request);
        Tasks task = await _unitOfWork.TasksRep.GetById(Guid.Parse(request.taskId));
        _unitOfWork.TasksRep.Delete(task);
        await _unitOfWork.SaveChangesAsync();
    }

    public async Task<Tasks> FindTaskByIdAsync(FindTaskRequest request)
    {
        _logger.LogInformation("Находим задачу: {@Request}", request);
        Tasks task = await _unitOfWork.TasksRep.GetById(Guid.Parse(request.taskId));
        return task;
    }
}