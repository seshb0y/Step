(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([typeof document === "object" ? document.currentScript : undefined, {

"[project]/src/app/components/common/Card.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/image.js [app-client] (ecmascript)");
"use client";
;
;
;
const Card = ({ href, title, image, fields })=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        href: href,
        style: {
            textDecoration: "none",
            maxWidth: 300,
            flex: "1 1 300px"
        },
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            style: {
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                background: "radial-gradient(circle at 60% 40%, #eaffd0 0%, #fff700 60%, #7fff00 100%)",
                border: "5px solid #39ff14",
                borderRadius: "32px 24px 36px 28px/28px 36px 24px 32px",
                boxShadow: "0 0 32px #7fff00cc, 0 0 0 8px #fff70055, 0 8px 32px #a259ff44, 0 0 0 6px #fff70044",
                padding: "32px 24px 24px 24px",
                margin: "0 auto",
                minWidth: 240,
                minHeight: 340,
                transition: "border 0.2s, box-shadow 0.2s, transform 0.18s cubic-bezier(.68,-0.55,.27,1.55)",
                outline: "5px solid #a259ff44",
                position: "relative",
                overflow: "hidden",
                animation: "jelly 0.7s cubic-bezier(.68,-0.55,.27,1.55)",
                cursor: "pointer"
            },
            onMouseEnter: (e)=>{
                e.currentTarget.style.transform = "scale(1.04) rotate(-2deg)";
                e.currentTarget.style.boxShadow = "0 0 48px #fff700cc, 0 0 0 12px #7fff0044, 0 8px 32px #a259ff77";
                e.currentTarget.style.border = "5px solid #fff700";
            },
            onMouseLeave: (e)=>{
                e.currentTarget.style.transform = "scale(1) rotate(0)";
                e.currentTarget.style.boxShadow = "0 0 32px #7fff00cc, 0 0 0 8px #fff70055, 0 8px 32px #a259ff44, 0 0 0 6px #fff70044";
                e.currentTarget.style.border = "5px solid #39ff14";
            },
            children: [
                image && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    src: image,
                    alt: title,
                    width: 160,
                    height: 160,
                    style: {
                        borderRadius: "22px",
                        marginBottom: "18px",
                        border: "4px solid #fff700",
                        boxShadow: "0 0 24px #39ff14, 0 0 0 4px #a259ff44",
                        background: "#fff"
                    }
                }, void 0, false, {
                    fileName: "[project]/src/app/components/common/Card.tsx",
                    lineNumber: 64,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                    style: {
                        color: "#a259ff",
                        margin: "12px 0 8px 0",
                        textAlign: "center",
                        fontSize: "1.5rem",
                        textShadow: "0 2px 4px #fff, 0 0 2px #000, 0 0 8px #7fff00",
                        fontWeight: 900,
                        letterSpacing: 1,
                        WebkitTextStroke: "0.5px #fff",
                        borderRadius: "8px",
                        padding: "2px 8px"
                    },
                    children: title
                }, void 0, false, {
                    fileName: "[project]/src/app/components/common/Card.tsx",
                    lineNumber: 78,
                    columnNumber: 7
                }, this),
                fields.map((field, idx)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        style: {
                            color: field.color || "#222",
                            margin: "0 0 8px 0",
                            fontWeight: 900,
                            fontSize: "1.15rem",
                            textShadow: "1px 1px 0 #fff, 0 0 8px #7fff00, 0 0 2px #fff700",
                            letterSpacing: 1
                        },
                        children: [
                            field.label,
                            ": ",
                            field.value
                        ]
                    }, idx, true, {
                        fileName: "[project]/src/app/components/common/Card.tsx",
                        lineNumber: 95,
                        columnNumber: 9
                    }, this))
            ]
        }, void 0, true, {
            fileName: "[project]/src/app/components/common/Card.tsx",
            lineNumber: 25,
            columnNumber: 5
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/app/components/common/Card.tsx",
        lineNumber: 21,
        columnNumber: 3
    }, this);
_c = Card;
const __TURBOPACK__default__export__ = Card;
var _c;
__turbopack_context__.k.register(_c, "Card");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/app/characters/page.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$components$2f$common$2f$Card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/app/components/common/Card.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
const Characters = ()=>{
    _s();
    const [characters, setCharacters] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Characters.useEffect": ()=>{
            async function fetchCharacters() {
                const res = await fetch("/api/character");
                const data = await res.json();
                setCharacters(data.results);
            }
            fetchCharacters();
        }
    }["Characters.useEffect"], []);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        style: {
            display: "flex",
            flexWrap: "wrap",
            gap: "40px",
            justifyContent: "center"
        },
        children: characters.map((char)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$components$2f$common$2f$Card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                href: `/characters/${char.id}`,
                title: char.name,
                image: char.image,
                fields: [
                    {
                        label: "Статус",
                        value: char.status,
                        color: "#39ff14"
                    },
                    {
                        label: "Создан",
                        value: new Date(char.created).toLocaleDateString()
                    }
                ]
            }, char.id, false, {
                fileName: "[project]/src/app/characters/page.tsx",
                lineNumber: 29,
                columnNumber: 9
            }, this))
    }, void 0, false, {
        fileName: "[project]/src/app/characters/page.tsx",
        lineNumber: 20,
        columnNumber: 5
    }, this);
};
_s(Characters, "Lpb9AbqKJ07+xuj4aZ1twNw87e0=");
_c = Characters;
const __TURBOPACK__default__export__ = Characters;
var _c;
__turbopack_context__.k.register(_c, "Characters");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
}]);

//# sourceMappingURL=src_app_ebf7f900._.js.map