module.exports = {

"[project]/src/app/location/page.tsx [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-ssr] (ecmascript)");
"use client";
;
;
;
const Location = ()=>{
    const [locations, setLocations] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        async function fetchLocations() {
            const res = await fetch("/api/location");
            const data = await res.json();
            setLocations(data.results);
        }
        fetchLocations();
    }, []);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        style: {
            display: "flex",
            flexWrap: "wrap",
            gap: "40px",
            justifyContent: "center"
        },
        children: locations.map((loc)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                href: `/location/${loc.id}`,
                style: {
                    textDecoration: "none",
                    maxWidth: 280,
                    flex: "1 1 280px"
                },
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    style: {
                        display: "flex",
                        flexDirection: "column",
                        alignItems: "center",
                        background: "radial-gradient(circle at 60% 40%, #fff700 0%, #eaffd0 60%, #7fff00 100%)",
                        border: "5px dashed #39ff14",
                        borderRadius: "32px 24px 36px 28px/28px 36px 24px 32px",
                        boxShadow: "0 0 40px #7fff00a0, 0 0 0 8px #fff70055, 0 8px 32px #a259ff44",
                        padding: "28px 20px 22px 20px",
                        margin: "0 auto",
                        minWidth: 230,
                        minHeight: 200,
                        transition: "border 0.2s, box-shadow 0.2s, transform 0.18s cubic-bezier(.68,-0.55,.27,1.55)",
                        outline: "5px solid #a259ff44",
                        position: "relative",
                        overflow: "hidden",
                        animation: "jelly 0.7s cubic-bezier(.68,-0.55,.27,1.55)",
                        cursor: "pointer"
                    },
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                            style: {
                                color: "#a259ff",
                                margin: "10px 0 6px 0",
                                textAlign: "center",
                                fontSize: "1.5rem",
                                textShadow: "2px 2px 0 #fff700, 0 0 12px #7fff00, 0 0 2px #fff",
                                fontWeight: 900,
                                letterSpacing: 1
                            },
                            children: loc.name
                        }, void 0, false, {
                            fileName: "[project]/src/app/location/page.tsx",
                            lineNumber: 56,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            style: {
                                color: "#39ff14",
                                margin: "0 0 6px 0",
                                fontWeight: 900,
                                fontSize: "1.15rem",
                                textShadow: "1px 1px 0 #fff, 0 0 8px #fff700"
                            },
                            children: [
                                "Тип: ",
                                loc.type
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/app/location/page.tsx",
                            lineNumber: 69,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            style: {
                                color: "#a259ff",
                                margin: "0 0 6px 0",
                                fontWeight: 900,
                                fontSize: "1.1rem",
                                textShadow: "1px 1px 0 #fff, 0 0 8px #fff700"
                            },
                            children: [
                                "Измерение: ",
                                loc.dimension
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/app/location/page.tsx",
                            lineNumber: 80,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            style: {
                                color: "#222",
                                fontSize: "1em",
                                margin: 0,
                                fontWeight: 700,
                                textShadow: "1px 1px 0 #fff700"
                            },
                            children: [
                                "Создан: ",
                                new Date(loc.created).toLocaleDateString()
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/app/location/page.tsx",
                            lineNumber: 91,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/app/location/page.tsx",
                    lineNumber: 32,
                    columnNumber: 11
                }, this)
            }, loc.id, false, {
                fileName: "[project]/src/app/location/page.tsx",
                lineNumber: 27,
                columnNumber: 9
            }, this))
    }, void 0, false, {
        fileName: "[project]/src/app/location/page.tsx",
        lineNumber: 18,
        columnNumber: 5
    }, this);
};
const __TURBOPACK__default__export__ = Location;
}}),

};

//# sourceMappingURL=src_app_location_page_tsx_f5a1bf32._.js.map