(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_next_d2ed38d8._.js",
  "static/chunks/src_app_characters_page_tsx_9bdb2056._.js"
],
    source: "dynamic"
});
