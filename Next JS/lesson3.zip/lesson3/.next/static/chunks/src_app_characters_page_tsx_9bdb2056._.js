(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([typeof document === "object" ? document.currentScript : undefined, {

"[project]/src/app/characters/page.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/image.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
const Characters = ()=>{
    _s();
    const [characters, setCharacters] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Characters.useEffect": ()=>{
            async function fetchCharacters() {
                const res = await fetch("/api/character");
                const data = await res.json();
                setCharacters(data.results);
            }
            fetchCharacters();
        }
    }["Characters.useEffect"], []);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        style: {
            display: "flex",
            flexWrap: "wrap",
            gap: "40px",
            justifyContent: "center"
        },
        children: characters.map((char)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                href: `/characters/${char.id}`,
                style: {
                    textDecoration: "none",
                    maxWidth: 280,
                    flex: "1 1 280px"
                },
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    style: {
                        display: "flex",
                        flexDirection: "column",
                        alignItems: "center",
                        background: "radial-gradient(circle at 60% 40%, #fff700 0%, #eaffd0 60%, #7fff00 100%)",
                        border: "5px dashed #39ff14",
                        borderRadius: "32px 24px 36px 28px/28px 36px 24px 32px",
                        boxShadow: "0 0 40px #7fff00a0, 0 0 0 8px #fff70055, 0 8px 32px #a259ff44",
                        padding: "28px 20px 22px 20px",
                        margin: "0 auto",
                        minWidth: 230,
                        minHeight: 340,
                        transition: "border 0.2s, box-shadow 0.2s, transform 0.18s cubic-bezier(.68,-0.55,.27,1.55)",
                        outline: "5px solid #a259ff44",
                        position: "relative",
                        overflow: "hidden",
                        animation: "jelly 0.7s cubic-bezier(.68,-0.55,.27,1.55)",
                        cursor: "pointer"
                    },
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            src: char.image,
                            alt: char.name,
                            width: 150,
                            height: 150,
                            style: {
                                borderRadius: "20px",
                                marginBottom: "18px",
                                border: "4px solid #fff700",
                                boxShadow: "0 0 20px #39ff14, 0 0 0 4px #a259ff44",
                                background: "#fff"
                            }
                        }, void 0, false, {
                            fileName: "[project]/src/app/characters/page.tsx",
                            lineNumber: 59,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                            style: {
                                color: "#a259ff",
                                margin: "10px 0 6px 0",
                                textAlign: "center",
                                fontSize: "1.5rem",
                                textShadow: "2px 2px 0 #fff700, 0 0 12px #7fff00, 0 0 2px #fff",
                                fontWeight: 900,
                                letterSpacing: 1
                            },
                            children: char.name
                        }, void 0, false, {
                            fileName: "[project]/src/app/characters/page.tsx",
                            lineNumber: 72,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            style: {
                                color: "#39ff14",
                                margin: "0 0 6px 0",
                                fontWeight: 900,
                                fontSize: "1.15rem",
                                textShadow: "1px 1px 0 #fff, 0 0 8px #fff700"
                            },
                            children: [
                                "Статус: ",
                                char.status
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/app/characters/page.tsx",
                            lineNumber: 85,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            style: {
                                color: "#222",
                                fontSize: "1em",
                                margin: 0,
                                fontWeight: 700,
                                textShadow: "1px 1px 0 #fff700"
                            },
                            children: [
                                "Создан: ",
                                new Date(char.created).toLocaleDateString()
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/app/characters/page.tsx",
                            lineNumber: 96,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/app/characters/page.tsx",
                    lineNumber: 35,
                    columnNumber: 11
                }, this)
            }, char.id, false, {
                fileName: "[project]/src/app/characters/page.tsx",
                lineNumber: 30,
                columnNumber: 9
            }, this))
    }, void 0, false, {
        fileName: "[project]/src/app/characters/page.tsx",
        lineNumber: 21,
        columnNumber: 5
    }, this);
};
_s(Characters, "Lpb9AbqKJ07+xuj4aZ1twNw87e0=");
_c = Characters;
const __TURBOPACK__default__export__ = Characters;
var _c;
__turbopack_context__.k.register(_c, "Characters");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
}]);

//# sourceMappingURL=src_app_characters_page_tsx_9bdb2056._.js.map