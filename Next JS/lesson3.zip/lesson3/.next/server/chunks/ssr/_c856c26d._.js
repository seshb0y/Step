module.exports = {

"[project]/.next-internal/server/app/characters/[id]/page/actions.js [app-rsc] (server actions loader, ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
}}),
"[project]/src/app/favicon.ico.mjs { IMAGE => \"[project]/src/app/favicon.ico (static in ecmascript)\" } [app-rsc] (structured image object, ecmascript, Next.js server component)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.n(__turbopack_context__.i("[project]/src/app/favicon.ico.mjs { IMAGE => \"[project]/src/app/favicon.ico (static in ecmascript)\" } [app-rsc] (structured image object, ecmascript)"));
}}),
"[project]/src/app/layout.tsx [app-rsc] (ecmascript, Next.js server component)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.n(__turbopack_context__.i("[project]/src/app/layout.tsx [app-rsc] (ecmascript)"));
}}),
"[project]/src/app/components/common/Card.tsx [app-rsc] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-jsx-dev-runtime.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/image.js [app-rsc] (ecmascript)");
;
;
;
const Card = ({ href, title, image, fields })=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
        href: href,
        style: {
            textDecoration: "none",
            maxWidth: 300,
            flex: "1 1 300px"
        },
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            style: {
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                background: "radial-gradient(circle at 60% 40%, #eaffd0 0%, #fff700 60%, #7fff00 100%)",
                border: "5px solid #39ff14",
                borderRadius: "32px 24px 36px 28px/28px 36px 24px 32px",
                boxShadow: "0 0 32px #7fff00cc, 0 0 0 8px #fff70055, 0 8px 32px #a259ff44, 0 0 0 6px #fff70044",
                padding: "32px 24px 24px 24px",
                margin: "0 auto",
                minWidth: 240,
                minHeight: 340,
                transition: "border 0.2s, box-shadow 0.2s, transform 0.18s cubic-bezier(.68,-0.55,.27,1.55)",
                outline: "5px solid #a259ff44",
                position: "relative",
                overflow: "hidden",
                animation: "jelly 0.7s cubic-bezier(.68,-0.55,.27,1.55)",
                cursor: "pointer"
            },
            onMouseEnter: (e)=>{
                e.currentTarget.style.transform = "scale(1.04) rotate(-2deg)";
                e.currentTarget.style.boxShadow = "0 0 48px #fff700cc, 0 0 0 12px #7fff0044, 0 8px 32px #a259ff77";
                e.currentTarget.style.border = "5px solid #fff700";
            },
            onMouseLeave: (e)=>{
                e.currentTarget.style.transform = "scale(1) rotate(0)";
                e.currentTarget.style.boxShadow = "0 0 32px #7fff00cc, 0 0 0 8px #fff70055, 0 8px 32px #a259ff44, 0 0 0 6px #fff70044";
                e.currentTarget.style.border = "5px solid #39ff14";
            },
            children: [
                image && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                    src: image,
                    alt: title,
                    width: 160,
                    height: 160,
                    style: {
                        borderRadius: "22px",
                        marginBottom: "18px",
                        border: "4px solid #fff700",
                        boxShadow: "0 0 24px #39ff14, 0 0 0 4px #a259ff44",
                        background: "#fff"
                    }
                }, void 0, false, {
                    fileName: "[project]/src/app/components/common/Card.tsx",
                    lineNumber: 62,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                    style: {
                        color: "#a259ff",
                        margin: "12px 0 8px 0",
                        textAlign: "center",
                        fontSize: "1.5rem",
                        textShadow: "0 2px 4px #fff, 0 0 2px #000, 0 0 8px #7fff00",
                        fontWeight: 900,
                        letterSpacing: 1,
                        WebkitTextStroke: "0.5px #fff",
                        borderRadius: "8px",
                        padding: "2px 8px"
                    },
                    children: title
                }, void 0, false, {
                    fileName: "[project]/src/app/components/common/Card.tsx",
                    lineNumber: 76,
                    columnNumber: 7
                }, this),
                fields.map((field, idx)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        style: {
                            color: field.color || "#222",
                            margin: "0 0 8px 0",
                            fontWeight: 900,
                            fontSize: "1.15rem",
                            textShadow: "1px 1px 0 #fff, 0 0 8px #7fff00, 0 0 2px #fff700",
                            letterSpacing: 1
                        },
                        children: [
                            field.label,
                            ": ",
                            field.value
                        ]
                    }, idx, true, {
                        fileName: "[project]/src/app/components/common/Card.tsx",
                        lineNumber: 93,
                        columnNumber: 9
                    }, this))
            ]
        }, void 0, true, {
            fileName: "[project]/src/app/components/common/Card.tsx",
            lineNumber: 23,
            columnNumber: 5
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/app/components/common/Card.tsx",
        lineNumber: 19,
        columnNumber: 3
    }, this);
const __TURBOPACK__default__export__ = Card;
}}),
"[project]/src/app/components/common/DetailCard.tsx [app-rsc] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-jsx-dev-runtime.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/image.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$components$2f$common$2f$Card$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/app/components/common/Card.tsx [app-rsc] (ecmascript)");
;
;
;
const DetailCard = ({ title, image, fields, links, children })=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        style: {
            maxWidth: "520px",
            margin: "40px auto",
            background: "radial-gradient(circle at 60% 40%, #fff700 0%, #eaffd0 60%, #7fff00 100%)",
            border: "5px dashed #39ff14",
            borderRadius: "36px 28px 40px 32px/32px 40px 28px 36px",
            padding: "40px 32px 32px 32px",
            boxShadow: "0 0 48px #7fff00a0, 0 0 0 10px #fff70055, 0 8px 32px #a259ff44",
            color: "#222",
            outline: "5px solid #a259ff44",
            position: "relative",
            overflow: "hidden",
            animation: "jelly 0.7s cubic-bezier(.68,-0.55,.27,1.55)"
        },
        children: [
            image && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                src: image,
                alt: title,
                width: 180,
                height: 180,
                style: {
                    borderRadius: "24px",
                    marginBottom: "18px",
                    border: "4px solid #fff700",
                    boxShadow: "0 0 20px #39ff14, 0 0 0 4px #a259ff44",
                    background: "#fff"
                }
            }, void 0, false, {
                fileName: "[project]/src/app/components/common/DetailCard.tsx",
                lineNumber: 51,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                style: {
                    color: "#a259ff",
                    marginBottom: "12px",
                    textShadow: "2px 2px 0 #fff700, 0 0 12px #7fff00, 0 0 2px #fff",
                    fontWeight: 900,
                    fontSize: "2rem"
                },
                children: title
            }, void 0, false, {
                fileName: "[project]/src/app/components/common/DetailCard.tsx",
                lineNumber: 65,
                columnNumber: 5
            }, this),
            fields.map((field, idx)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("b", {
                            style: {
                                color: field.accentColor || "#39ff14"
                            },
                            children: [
                                field.label,
                                ":"
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/app/components/common/DetailCard.tsx",
                            lineNumber: 78,
                            columnNumber: 9
                        }, this),
                        " ",
                        field.value
                    ]
                }, idx, true, {
                    fileName: "[project]/src/app/components/common/DetailCard.tsx",
                    lineNumber: 77,
                    columnNumber: 7
                }, this)),
            links && links.map((link, idx)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("b", {
                                style: {
                                    color: link.accentColor || "#39ff14"
                                },
                                children: [
                                    link.label,
                                    ":"
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/components/common/DetailCard.tsx",
                                lineNumber: 86,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/app/components/common/DetailCard.tsx",
                            lineNumber: 85,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            style: {
                                display: "flex",
                                flexWrap: "wrap",
                                gap: 16
                            },
                            children: link.urls.map((url)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$components$2f$common$2f$Card$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                                    href: url,
                                    title: url.split("/").pop() || url,
                                    fields: []
                                }, url, false, {
                                    fileName: "[project]/src/app/components/common/DetailCard.tsx",
                                    lineNumber: 92,
                                    columnNumber: 15
                                }, this))
                        }, void 0, false, {
                            fileName: "[project]/src/app/components/common/DetailCard.tsx",
                            lineNumber: 90,
                            columnNumber: 11
                        }, this)
                    ]
                }, idx, true, {
                    fileName: "[project]/src/app/components/common/DetailCard.tsx",
                    lineNumber: 84,
                    columnNumber: 9
                }, this)),
            children
        ]
    }, void 0, true, {
        fileName: "[project]/src/app/components/common/DetailCard.tsx",
        lineNumber: 32,
        columnNumber: 3
    }, this);
const __TURBOPACK__default__export__ = DetailCard;
}}),
"[project]/src/app/characters/[id]/page.tsx [app-rsc] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>CharacterPage)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-jsx-dev-runtime.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$components$2f$common$2f$DetailCard$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/app/components/common/DetailCard.tsx [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-rsc] (ecmascript)");
;
;
;
async function CharacterPage({ params }) {
    const res = await fetch(`http://localhost:3000/api/character/${params.id}`);
    const character = await res.json();
    const fields = [
        {
            label: "Статус",
            value: character.status,
            accentColor: "#39ff14"
        },
        {
            label: "Вид",
            value: character.species,
            accentColor: "#a259ff"
        },
        {
            label: "Тип",
            value: character.type || "—",
            accentColor: "#39ff14"
        },
        {
            label: "Гендер",
            value: character.gender,
            accentColor: "#a259ff"
        },
        {
            label: "Место происхождения",
            value: character.origin?.name,
            accentColor: "#39ff14"
        },
        {
            label: "Локация",
            value: character.location?.name,
            accentColor: "#a259ff"
        },
        {
            label: "Создан",
            value: new Date(character.created).toLocaleString(),
            accentColor: "#39ff14"
        }
    ];
    const links = [
        {
            label: "Эпизоды",
            urls: character.episode,
            accentColor: "#39ff14"
        }
    ];
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$components$2f$common$2f$DetailCard$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                title: character.name,
                image: character.image,
                fields: fields,
                links: links
            }, void 0, false, {
                fileName: "[project]/src/app/characters/[id]/page.tsx",
                lineNumber: 41,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                href: "/characters",
                style: {
                    display: "inline-block",
                    margin: "24px auto 0 auto",
                    background: "#fff700",
                    color: "#222",
                    fontWeight: 900,
                    fontFamily: "Luckiest Guy, cursive",
                    border: "3px solid #39ff14",
                    borderRadius: 16,
                    padding: "10px 28px",
                    textDecoration: "none",
                    boxShadow: "0 2px 12px #00e6ff44",
                    outline: "3px solid #a259ff44",
                    fontSize: "1.1rem",
                    transition: "background 0.2s, color 0.2s, box-shadow 0.2s, transform 0.15s",
                    maxWidth: 300,
                    textAlign: "center"
                },
                children: "Назад к персонажам"
            }, void 0, false, {
                fileName: "[project]/src/app/characters/[id]/page.tsx",
                lineNumber: 47,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true);
}
}}),
"[project]/src/app/characters/[id]/page.tsx [app-rsc] (ecmascript, Next.js server component)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.n(__turbopack_context__.i("[project]/src/app/characters/[id]/page.tsx [app-rsc] (ecmascript)"));
}}),

};

//# sourceMappingURL=_c856c26d._.js.map